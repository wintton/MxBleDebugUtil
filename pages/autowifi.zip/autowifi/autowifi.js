// pages/autowifi/autowifi.js
var util = require("../../utils/util.js");
import drawQrcode from '../../utils/qrcode.min.js'; 
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    wifilist: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

   

    //wx.getFuzzyLocation();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    wx.offWifiConnected(wifiConnectLisenter);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }, 
  doCloseDialog(res) {
    this.setData({
      show: false
    })
  },
  doConnect(res){
    let that = this;
    let ssid = that.data.ssid;
    let password = that.data.password;
    if(!ssid || !password){
        util.showHintModal("wifi名称或wifi密码为空");
        return;
    }
  
    wx.startWifi({
      success(res) {
        if (res.errCode != 0) {
          util.showHintModal("当前未打开WIFI，请打开WIFI后重试");
          return;
        }
        // wx.onWifiConnected(wifiConnectLisenter);
        wx.showLoading({
          title: '连接中',
        })
        wx.connectWifi({
          SSID: ssid,
          password: password, 
          success:res => {
            console.log(res)
          },
          fail:res => {
            console.log(res)
          }
        })
      },
      fail(res) {
        util.showHintModal("当前未打开WIFI，请打开WIFI后重试");
      }
    }) 
  },
  doSaveImg(res) {
    let that = this;
    var filepath = wx.env.USER_DATA_PATH + '/test.png';
    //获取文件管理器对象
    var aa = wx.getFileSystemManager();
    aa.writeFile({
      filePath: filepath,
      data: that.data.imageDataBuffer,
      encoding: 'base64',
      success: res => {
        wx.showLoading({
          title: '正在保存...',
          mask: true
        });
        wx.saveImageToPhotosAlbum({
          filePath: filepath,
          success(res) {
            wx.hideLoading()
            wx.showModal({
              title: '提示',
              showCancel: false,
              confirmText: "我知道了",
              content: '已保存至本地',
            })
          },
          fail: function (res) {
            wx.showModal({
              title: '提示',
              showCancel: false,
              confirmText: "我知道了",
              content: '保存失败',
            })
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    }); 
  },
  doSubmit(res) {
    let id = "qcode";
    const {
      ssid,
      password
    } = res.detail.value;
    if (!ssid) {
      util.showHintModal("WIFI名称不能为空");
      return;
    }
    if (!password) {
      util.showHintModal("WIFI密码不能为空");
      return;
    } 
    this.setData({
      ssid,
      password
    })
    doGetAccessToken(this);
  },
  doChangeImg(res) {
    let that = this;


    wx.chooseMedia({
      count: 1,
      mediaType: ["image"],
      success: res => {
        let file = res.tempFiles[0];
        that.setData({
          img_path: file.tempFilePath
        })
      }
    })
  }
})

function doGetAccessToken(that) {
  wx.showLoading({
    title: '',
  })
  let reqdata = {
    appid: app.globalData.appid
  }
  let success = res => {
    wx.hideLoading();
    if (res.data.access_token) {
      doGetImageData(res.data.access_token, that);
    } else {
      util.showHintModal("获取token失败");
    }
  }
  util.requestGet("/wechat/getToken", reqdata, success);
}


function doGetImageData(access_token, that) {
  wx.showLoading({
    title: '',
  })
  let reqdata = {
    path: "pages/connectwifi/connectwifi?ssid=" + that.data.ssid + "&pwd=" + that.data.password,
    width: 430
  }
  let success = res => {
    wx.hideLoading();
    if (res.data.code == 0) {
      let bufferImg = wx.arrayBufferToBase64(res.data.result);
      that.setData({
        imageData:  "data:image/png;base64," +  bufferImg,
        imageDataBuffer:bufferImg,
        show: true
      });
    } else {
      util.showHintModal("获取图片失败");
    }
  }
  util.requestPost("/wechat/createWXQrcode?access_token=" + access_token, reqdata, success);
}

const wifiConnectLisenter = res => {
  console.log(res)
}